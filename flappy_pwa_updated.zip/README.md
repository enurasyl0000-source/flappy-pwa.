# Flappy Bird PWA

Простая аркадная игра на HTML5 + JS, оформленная как PWA.

## 🚀 Запуск
- Открой `index.html` в браузере  
- Или залей проект на GitHub Pages / Netlify

## 📱 Установка на телефон
- Зайди на сайт через Chrome (Android)  
- Нажми «Добавить на главный экран»  
- Играй офлайн как в обычное приложение!

## ⚙ Настройки
- Gravity, Jump Force, Pipe Speed, Pipe Gap, Start Y можно менять прямо в игре.
- Есть кнопка «Normal Trajectory» для стандартных настроек.

